#! /usr/bin/env python
 
from py_lib.DistanceGPS import DistanceGPS

if __name__ == '__main__':
 
    try:
        gps = DistanceGPS()
        
        lat_p1 = float(input("input latitude  of Point1: "))
        lon_p1 = float(input("input longitude of Point1: "))
        lat_p2 = float(input("input latitude  of Point2: "))
        lon_p2 = float(input("input longitude of Point2: "))
        
        distance = gps.get_distance(lat_p1, lon_p1, lat_p2, lon_p2)
        bearing  = gps.get_bearing( lat_p1, lon_p1, lat_p2, lon_p2)
        
        print("distance = %f, bearing = %f." %(distance, bearing))
    
    except KeyboardInterrupt:
        pass
    
