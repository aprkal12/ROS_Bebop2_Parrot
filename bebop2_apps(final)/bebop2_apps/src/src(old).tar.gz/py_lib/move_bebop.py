#!/usr/bin/env python
 
from __future__ import print_function
import rospy, math
from geometry_msgs.msg import Twist
from std_msgs.msg import Empty
from math import pow, sqrt, atan, pi, radians
from bebop_msgs.msg import Ardrone3PilotingStateAltitudeChanged

DEFAULT_LIN_SPEED = 0.25
DEFAULT_ANG_SPEED = pi/12

MISSION_HEIGHT    = 0.8
RETUEN_HEIGHT     = 1.75

class Taker:
    
    def __init__(self):
    
        rospy.init_node('bb2_taker', anonymous=True)
    
        self.pb_takeoff = rospy.Publisher('bebop/takeoff', Empty, queue_size = 1)
        self.pb_land    = rospy.Publisher('bebop/land',    Empty, queue_size = 1)
        self.pb_twist   = rospy.Publisher('bebop/cmd_vel', Twist, queue_size = 1)
        
        rospy.Subscriber("bebop/states/ardrone3/PilotingState/AltitudeChanged", 
                         Ardrone3PilotingStateAltitudeChanged, 
                         self.get_height)
                     
        rospy.sleep(1)
        
        self.rate = rospy.Rate(10)
        
        self.e  = Empty()
        self.t  = Twist()
        
        self.current_height = 0
        
        self.mission_started = False
        
    def get_height(self,msg):
    
        self.current_height = msg.altitude
        '''
        if( self.mission_started is True ):
            if( msg.altitude > MISSION_HEIGHT ):
                self.t.linear.z = -0.1
                self.pb_twist(self.t)
            else:
                self.t.linear.z = 0.0                
                self.pb_twist(self.t)
                self.start_mission()            
        else:
            print(msg.altitude)
        '''
    def take_off(self):
        self.pb_takeoff.publish(self.e)
        print("take off")
        
    def land(self):
        self.pb_land.publish(self.e)
        print("land")
        
    def move(self, direction, dist):
        
        duration = (dist / 2) / DEFAULT_LIN_SPEED
        time2end = rospy.Time.now() + rospy.Duration(duration)
        
        self.t.linear.x  = DEFAULT_LIN_SPEED * 0.75;
        
        if(direction != 1):
            self.t.linear.x = -self.t.linear.x
        
        while(rospy.Time.now() < time2end):
            print( time2end - rospy.Time.now())
            self.pb_twist.publish(self.t)    
        
        self.t.linear.x = 0.0
        self.pb_twist.publish(self.t)
        
    def rotate(self, direction, ang):
    
        ang = radians(ang)
        
        duration = ang / 2 / DEFAULT_ANG_SPEED * 1.15
        time2end = rospy.Time.now() + rospy.Duration(duration)
        
        self.t.angular.z  = DEFAULT_ANG_SPEED;
        
        if(direction != 1):
            self.t.angular.z = -self.t.angular.z
        
        while(rospy.Time.now() < time2end):
            print( time2end - rospy.Time.now())
            self.pb_twist.publish(self.t)   
        
        self.t.angular.z = 0.0
        self.pb_twist.publish(self.t)
    
    def up_down(self, direction, height):
        
        self.t.linear.z  = DEFAULT_LIN_SPEED;
        
        if(direction != 1):
            self.t.linear.z = -self.t.linear.z
            
            while( self.current_height > height ):
                self.pb_twist.publish(self.t)
            
            self.t.linear.z = 0.0
            self.pb_twist.publish(self.t)
            
        else:
            while( self.current_height < height ):
                self.pb_twist.publish(self.t)
            
            self.t.linear.z = 0.0
            self.pb_twist.publish(self.t)
        
    def mission_start(self):
        #self.take_off()
        self.up_down(0, 0.8)
        self.move(1, 1.0)
        self.up_down(1, 1.5)
        self.rotate(1, 180)
        self.move(1, 1.2)
        self.land()
    
    def seaquance1(self):
        self.move(1, 1.0);
        self.rotate(0, 45)
        self.move(1, 0.5)
        self.up_down(0, 0.9)
        self.move(1, 1.0)
        self.up_down(1, 1.5)
        self.rotate(1, 180)
        self.move(1, 1.2)
        self.rotate(1, 45)
        self.move(1, 0.8)
        
        
                
if __name__ == '__main__':

    try:
        taker = Taker()
        
        taker.take_off();        rospy.sleep(4)
        taker.seaquance1()
        '''
        rospy.sleep(4)
        #taker.mission_start()
        rospy.sleep(5)
        taker.up_down(0, 0.8)
        rospy.sleep(2)
        taker.move(1, 1.5)
        rospy.sleep(2)
        taker.up_down(1, 1.5)
        rospy.sleep(2)
        taker.rotate(1, 215)
        rospy.sleep(2)
        taker.move(1, 1.5)
        rospy.sleep(3)
        '''
        taker.land()
        
        rospy.spin()
        
    except rospy.ROSInterruptException:   pass
